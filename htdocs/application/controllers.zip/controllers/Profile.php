<?php

class Profile extends MY_Controller{

	function __construct(){
		
	}
}
?>