<div class='container'>
	<div class='row'>
		<div class='col-md-12' style="text-align: center; margin-top: 10%;">
			<h1>You have successfully completed the setup!</h1>
			<h3>Please use your newly created super admin account to login</h3>
			<a class='btn btn-default' href="<?php echo base_url(); ?>logout">Login</a>
		</div>
	</div>
</div>