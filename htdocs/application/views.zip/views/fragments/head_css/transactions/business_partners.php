<link href='<?php echo base_url(); ?>/assets/css/transactions_business_partners.css' rel='stylesheet'>
<style>
	.side-body .row:first-child a:hover{
		background-color: #ECECEC !important;
	}
</style>