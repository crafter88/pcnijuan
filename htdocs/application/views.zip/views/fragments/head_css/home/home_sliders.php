<link href='<?php echo base_url(); ?>/libs/fullcalendar/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url(); ?>/libs/fullcalendar/fullcalendar.print.css' rel='stylesheet' media='print' />
<link href='<?php echo base_url(); ?>/assets/css/memo_slider.css' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url(); ?>/libs/sequence/css/sequence.css' rel='stylesheet' type='text/css'>