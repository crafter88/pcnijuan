<style>
.title-hover:hover{
	border: 2px solid #D5D5D5 !important;
}
.title-hover{
	height: 100px !important;
}

</style>