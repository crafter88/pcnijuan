<style>
	table th{
		font-size: 11px;
	}
	#report, #summary{
		width: 100%;
		overflow-x: auto;
	}
	#report table, #summary table{
		width: 1500px;
	}
</style>