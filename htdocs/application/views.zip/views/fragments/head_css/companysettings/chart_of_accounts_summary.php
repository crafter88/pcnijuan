<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>libs/datatable-report/buttons.dataTables.min.css">
<style>
	.dataTables_wrapper table.dataTable thead{
		background-color: #EEEEEE !important;
	}
	.dataTables_wrapper table.dataTable thead th{
		color: #000 !important;
	}
	.dataTables_wrapper table.dataTable{
		font-size: 11px !important;
	}
	.dataTables_wrapper .row:first-child{
		display: block !important;
	}
	.dt-buttons{
		width: 270px !important;
		text-align: center;
	}
	.dt-buttons a{
		float: left;
	}
</style>
