<script>
	$(document).ready(function(){
		$('#value-added-tax-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>