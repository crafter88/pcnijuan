<script>
	$(document).ready(function(){
		$('#financial-statements-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>