<script>
	$(document).ready(function(){
		$('#general-ledger-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>