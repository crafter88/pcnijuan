<script>
	$(document).ready(function(){
		$('#trial-balance-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>