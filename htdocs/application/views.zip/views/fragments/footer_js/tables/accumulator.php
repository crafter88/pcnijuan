<script>
	$(document).ready(function(){
		$('#accumulator-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>