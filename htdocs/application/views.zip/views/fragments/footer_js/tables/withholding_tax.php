<script>
	$(document).ready(function(){
		$('#withholding-tax-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>