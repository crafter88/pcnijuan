<script>
	$(document).ready(function(){
		$('#subsidiary-ledger-table').DataTable({
			lengthChange: false,
			scrollX: true
		});
	});
</script>