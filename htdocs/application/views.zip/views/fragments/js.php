<script src="<?php echo base_url(); ?>/libs/metro/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/libs/metro/js/metro.js"></script>
<script>
	$(function(){
		var form = $(".login-form");
		form.css({
			opacity: 1,
			"-webkit-transform": "scale(1)",
			"transform": "scale(1)",
			"-webkit-transition": ".5s",
			"transition": ".5s"
		});
	});
</script>