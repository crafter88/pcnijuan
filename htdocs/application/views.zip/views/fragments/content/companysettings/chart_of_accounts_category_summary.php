<div class='side-body padding-top'>
	<div class='card custom-card'>
		<div class='card-body' style='padding: 10px 20px 0px 20px;'>
			<div class='row'>
				<div class='col-md-12' id='chart-of-accounts-table-row'>
					<table id='summary-category' class='table table-bordered'>
						<thead>
							<th>Code 1</th>
							<th>Elements</th>
							<th>Code 2</th>
							<th>Classification</th>
							<th>Code 3</th>
							<th>Line Items</th>
							<th>Code 4</th>
							<th>Account Subclassification</th>
							<th>Code 5</th>
							<th>Subsidiary Account Name</th>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
