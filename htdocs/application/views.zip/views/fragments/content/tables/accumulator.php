
<div class='side-body padding-top' id="content-responsive">
	<div class='card'>
		<div class='card-header'>
			<div class='card-title'>
				<div class='title'>Accumulator</div>
			</div>
		</div>
		<div class='card-body'>
		</div>
	</div>
</div>

