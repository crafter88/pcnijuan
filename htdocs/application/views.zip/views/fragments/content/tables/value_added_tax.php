
<div class='side-body padding-top' id="content-responsive">
	<div class='card'>
		<div class='card-header'>
			<div class='card-title'>
				<div class='title'>Value Added Tax</div>
			</div>
		</div>
		<div class='card-body'>
			<table class='table table-hover table-bordered table-striped'>
				<thead>
					<th>Journal</th>
					<th>Transaction Code</th>
					<th>Tax Code</th>
					<th>Nature</th>
					<th>Rate</th>
					<th>VAT</th>
					<th>Net VAT Amount</th>
					<th>Gross Amount</th>
				</thead>
			</table>
		</div>
	</div>
</div>

