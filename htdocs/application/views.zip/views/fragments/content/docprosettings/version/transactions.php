<div class='side-body padding-top'>
	<div class='card'>
		<div class='card-header'>
			<div class='card-title'>
				<div class='title'>Transactions</div>
			</div>
		</div>
		<div class='card-body' style='padding-top: 10px;'>
			<div class='row'>
				<div class='col-md-12' id='transactions-table-row'>
					<table id='transactions-table' class='table table-hovered table-bordered' width='100%'>
						<thead>
							<th>Options</th>
							<th>Code</th>
							<th>Journal Short Name</th>
							<th>Category</th>
							<th>Nature</th>
							<th>Sequence</th>
							<th>Account Name</th>
							<th>Factor</th>
							<th>Basis</th>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>