<div id='m_c_d' class='appear'>
    <div class='n_cp_n_cm' class='container' style="margin: 0;">
		<div class='card-body button-group-custom'>
			<div class='row'>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">General Ledger</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Subsidiary Ledger</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Sales</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Receipts</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Collections</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Purchases</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Disbursements</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Adjustments</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-sm-3 col-xs-12 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Others</h4>
					</span>
				</a>
			</div>
		</div>
	</div>
</div>