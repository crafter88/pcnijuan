<div id='m_c_d' class='appear'>
    <div class='n_cp_n_cm' class='container' style="margin: 0;">
		<div class='card-body button-group-custom'>
			<div class='row'>
<!-- 				<a href='<?php echo base_url(); ?>docpro_setup/chart_of_accounts' class="col-md-3 col-xs-3 col-sm-3 <?php echo (floatval($coa_count) > 0) ? 'dp-tiles-full' : 'dp-tiles'; ?> ripple-effect">
					<span class="tile-number">1</span>
					<h4 style="text-align: center; margin: 0;">Docpro</h4>
					<h4 style="text-align: center; font-weight: bold;">Chart of Accounts</h4>
				</a>
				<a href='<?php echo base_url(); ?>docpro_setup/taxes' class='col-md-3 col-xs-3 col-sm-3 <?php echo (floatval($tax_types_count) > 0) ? 'dp-tiles-full' : 'dp-tiles'; ?> ripple-effect'>
					<span class="tile-number">2</span>
					<h4 style="text-align: center; margin: 0;">Docpro</h4>
					<h4 style="text-align: center; font-weight: bold;">Taxes</h4>
				</a> -->
				<a href='<?php echo base_url(); ?>docpro_setup/chart_of_accounts' class="col-md-2 col-xs-2 col-sm-2 title-hover <?php echo (floatval($coa_count) > 0) ? 'dp-tiles-full' : 'dp-tiles'; ?>">
					<span>
						<h4 style="text-align: center; margin: 0;">DocPro</h4>
						<h4 style="text-align: center; font-weight: bold;">Chart of Accounts</h4>
					</span>
				</a>
				<a href='<?php echo base_url(); ?>docpro_setup/taxes' class="col-md-2 col-xs-2 col-sm-2 title-hover <?php echo (floatval($coa_count) > 0) ? 'dp-tiles-full' : 'dp-tiles'; ?>">
					<span>
						<h4 style="text-align: center; margin: 0;">DocPro</h4>
						<h4 style="text-align: center; font-weight: bold;">Taxes</h4>
					</span>
				</a>
			</div>
		</div>
	</div>
</div>