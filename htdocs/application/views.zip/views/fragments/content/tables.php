<div id='m_c_d' class='appear'>
    <div class='n_cp_n_cm' class='container' style="margin: 0;">
		<div class='card-body button-group-custom'>
			<div class='row'>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Value Added Tax</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Witholding Tax</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Accumulator</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Financial Statements</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Trial Balance</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">General Ledger</h4>
					</span>
				</a>
				<a href='#' class="col-md-3 col-xs-3 col-sm-3 title-hover dp-tiles">
					<span>
						<h4 style="text-align: center; margin: 0;">Company</h4>
						<h4 style="text-align: center; font-weight: bold;">Subsidiary Ledger</h4>
					</span>
				</a>
			</div>
		</div>
	</div>
</div>