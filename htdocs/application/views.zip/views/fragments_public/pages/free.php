<div id='setup-banner' style="background-color: #1d55cc; border-bottom: 1px solid #ddd; margin: 0; width: 100%; padding: 10px; height: 58px; font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; ">
  <span style="font-weight: bold; font-size: 18px; color: #FFF;"><img src='<?php echo base_url(); ?>assets/img/250x250.png' id='banner-logo' style='height: 37px; margin-right: 15px;' /> DocPro Accounting System</span>
  <a href="<?php echo base_url(); ?>" style="float: right; color: #FFF; margin-top: 10px; margin-right: 50px; text-decoration: none;"><i class='fa fa-sign-in'></i>&nbsp; Login</a>
</div>

  <div class='container' id="free-container">
    <div class='row' style="width: 100%; margin: 0 auto;">
<!--         <div class='col-md-6' >
           <div class='panel' id='free-title-opacity'>
              <div class="panel-heading" style="padding: 0 20px; background-color: #2c3e50; color: #FFF">
                <h3 style="padding-top: 10px; text-align: center;">FREE Subscription</h3>
              </div>
              <div class='panel-body'>
                <p style="font-size: 18px; text-align: center; font-weight: bold;">
                  Affordable Plan
                </p>
                <p style="font-size: 14px; text-align: center; font-weight: bold;">at</p>
                <h1 style="text-align: center; font-size: 72px;"><i class='fa fa-rub'></i>0 <span style="font-size: 13px; color: #000">/ 30 days Only!</span></h1>
                 <ul style="list-style: initial; margin-left: 30%; margin-top: 30px; font-size: 18px; color: #8a8989;">
                    <li class="available-feature"><em>30 Days Trial</em></li>
                    <li class="available-feature"><em>1 Admin Account</em></li>
                    <li class="available-feature"><em>2 User Accounts</em></li>
                    <li class="available-feature"><em>Limited Features</em></li>
                  </ul>
              </div>              
           </div>           
        </div> -->
<!--         <div class='col-md-6 subscribe-panel' style="background-color: #FFF;">
          <form name='free_subscription' id="msform" action="<?php echo base_url(); ?>save/free" method="post" role="form">
              <h2 class="fs-title" style="font-size: 18px;">Company</h2>
              <div>
                  <label class='input-label'>Trade Name</label>
                  <input class='form-control no-space required input-count' type="text" name="trade_name" placeholder='For Non-individual' required />
              </div>
              <div>
                  <label class='input-label'>Company Name</label>
                  <input class='form-control no-space required input-count' type="text" name="company" placeholder='For Non-individual' required />
              </div>
              <label class='or'>- OR -</label>
              <div>
                <label class='input-label'>Owner's Name</label>
                <input class='form-control no-space required input-count' type="text" name="owner_name" placeholder='Last name, First name Middle initial(.)' required />
              </div>
              <div>
                <label class='input-label'>Address</label>
                <textarea class='form-control no-space required input-count' type="text" name="company_address" placeholder='# no street name, City, Province' required ></textarea>
              </div>
              <div>
                <label class='input-label'>Mobile Number</label>
                <input class='form-control no-space required input-count number' type="text" name="company_cp_no" placeholder='09xxxxxxxxx' required />
              </div>
              <div>
                <label class='input-label'>Email Address</label>
                <input class='form-control no-space required input-count email' type="text" name="company_email" placeholder='ex: someone@company.com' required />
              </div>
              <label class='registrant' style="font-size: 18px; margin-top: 50px;">Registrant Information</label>
              <div>
                <label class='input-label'>Registrant Name</label>
                <input class='form-control no-space required input-count' type="text" name="registrant_name" placeholder='Last name, First name Middle initial(.)' required />
              </div>
              <div>
                <label class='input-label'>Mobile Number</label>
                <input class='form-control no-space required input-count number' type="text" name="registrant_cp_no" placeholder='09xxxxxxxxx' required />
              </div>
              <div>
                <label class='input-label'>Email Address</label>
                <input class='form-control no-space required input-count email' type="text" name="registrant_email" placeholder='ex: someone@company.com' required />
              </div>
              <div>
                <button type="submit" class="btn btn-default action-button" disabled="disabled">Ok</button>
                <p class='submit-notice'>*Please fill all required fields</p>
              </div>
          </form>
        </div> -->
        <div class='col-md-6 col-md-offset-3 subscribe-panel' style="background-color: #FFF;">
          <form name='free_subscription' id="msform" action="<?php echo base_url(); ?>save/free" method="post" role="form">
              <div class='col-md-12'>
                <div class="alert alert-danger v-notice" role="alert" style="display: none;">
                    <div style="color: red; font-size: 14px; font-weight: bold; text-align: center;"><i class='fa fa-warning'></i>&nbsp; WARNING!</div>
                    <div style="color: red;"><i class='fa fa-circle' style="font-size: 8px;"></i>&nbsp; Please fill-in all required fields</div>
                    <div style="color: orange;"><i class='fa fa-circle' style="font-size: 8px;"></i>&nbsp; Please correct all invalid formats</div>
                </div>
              </div>
              <h2 class="fs-title" style="font-size: 18px;">Company</h2>
              <table class='table'>
                <tr>
                  <td><label>Company or Individual Name</label></td>
                  <td><input class='form-control v-required' type="text" name="co_name"></td>
                </tr>
                <tr>
                  <td><label>Trade Name</label></td>
                  <td><input class='form-control' type="text" name="co_trade_name"></td>
                </tr>
                <tr>
                  <td><label>Business Address</label></td>
                  <td><input class='form-control' type="text" name="co_ba_number" placeholder="Room / Floor / Building Number / Building Name"></td>
                </tr>
                <tr>
                  <td></td>
                  <td><input class='form-control v-required' type="text" name="co_ba_street" placeholder='Street'></td>
                </tr>
                <tr>
                  <td></td>
                  <td><input class='form-control' type="text" name="co_ba_brangay" placeholder="Barangay"></td>
                </tr>
                <tr>
                  <td></td>
                  <td><input class='form-control v-required' type="text" name="co_ba_city" placeholder="City or Municipality"></td>
                </tr>
                <tr>
                  <td></td>
                  <td><input class='form-control' type="text" name="co_ba_province" placeholder="Province"></td>
                </tr>
                <tr>
                  <td></td>
                  <td><input class='form-control v-number v-format' f='[0-9]{4}' type="text" name="co_ba_zip" title='4 digit zip code' placeholder="ZIP Code"></td>
                </tr>
                <tr>
                  <td><label>Contact Number</label></td>
                  <td><input class='form-control v-format' f='^([0-9]{3}\-[0-9]{3}\-[0-9]{4}|[0-9]{11})$' type="text" title='Landline (xxx-xxx-xxxx) OR Mobile (09xxxxxxxxx)' name="co_number"></td>
                </tr>
                <tr>
                  <td><label>Email</label></td>
                  <td><input class='form-control v-format' f='@{1}' title="email contains '@'" type="text" name="co_email"></td>
                </tr>
              </table>
              <h2 class="fs-title" style="font-size: 18px; margin-top: 30px;">Registrant Information</h2>
              <table class='table'>
                <tr>
                  <td><label>Name</label></td>
                  <td><input class='form-control v-required v-format' f='^[a-zA-Z]+\s?\-?[a-zA-Z]*\,\s[a-zA-Z]+\s?\-?[a-zA-Z]*\,\s+[a-zA-Z]+\-?[a-zA-Z]*\.?$' type="text" name="re_name" placeholder="Family Name, Given Name, Middle Name" title='Family Name, Given Name, Middle Name'></td>
                </tr>
                <tr>
                  <td><label>Contact Number</label></td>
                  <td><input class='form-control v-required v-format' f='^([0-9]{3}\-[0-9]{3}\-[0-9]{4}|[0-9]{11})$' type="text" title='Landline (xxx-xxx-xxxx) OR Mobile (09xxxxxxxxx)' type="text" name="re_number"></td>
                </tr>
                <tr>
                  <td><label>Email</label></td>
                  <td><input class='form-control v-required v-format' f='@{1}' title="email contains '@'" type="text" name="re_email"></td>
                </tr>
              </table>
              <button class='btn btn-primary v-submit' type="button">Submit</button>
          </form>
        </div>
    </div>

    <!-- <footer class="footer" id="free-footer">
    <div class="margin">
      <div class="menu-footer">
        <a href="#home">Home</a>
        <a href="#">FAQ</a>
        <a href="#">Privacy policy</a>
        <a href="#">Terms & Condition</a>
      </div>
      <div class="copyright">&copy; 2016. All Rights Reserved DocPro Business Solution</div>        
    </div>
  </footer>
  </div> -->

  <!-- Footer section -->

  




