<style>
	body > .container
	{
		background-image: url('assets/img/banner-sign-up.jpg');
	}
</style>