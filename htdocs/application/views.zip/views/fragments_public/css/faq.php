<link href="<?php echo base_url(); ?>libs/moderna/css/bootstrap.min.css" rel='stylesheet' type='text/css'>

<style>
	#faq1 {
		position: absolute;
		z-index: 1;
	}

	#faq2 {
		position: relative;
		z-index: 2;
	}

	#faq3 {
		position: relative;
		z-index: 3;
	}

	#faq4 {
		position: relative;
		z-index: 4;
	}
</style>
