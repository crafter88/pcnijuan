<script src="<?php echo base_url(); ?>libs/moderna/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/jquery.easing.1.3.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/jquery.fancybox.pack.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/jquery.fancybox-media.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/google-code-prettify/prettify.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/portfolio/jquery.quicksand.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/portfolio/setting.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/jquery.flexslider.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/animate.js"></script>
<script src="<?php echo base_url(); ?>libs/moderna/js/custom.js"></script>

<script src="<?php echo base_url(); ?>/libs/metro/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/libs/metro/js/metro.js"></script>
<script>
	$(function(){
		var form = $(".login-form");
		form.css({
			opacity: 1,
			"-webkit-transform": "scale(1)",
			"transform": "scale(1)",
			"-webkit-transition": ".5s",
			"transition": ".5s"
		});
	});
</script>