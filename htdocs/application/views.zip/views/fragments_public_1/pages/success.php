  <!-- section menu mobile -->
  
  <section class="menu-media">
  
    <div class="menu-content">
    
      <div class="logo">DOCPro System</div>
      
      <div class="icon"><a href="#"><img src="<?php echo base_url(); ?>libs/onepage/HTML/img/icons/menu-media.png"/></a></div>
    
    </div>
   
  </section>

  <!-- section menu -->

  <section class="menu">

    <div class="menu-content">
    
    <div class="logo">DOCPro System</div>

  </section>

  
  <section class="partners parallax-background-partners" id="partners" style="background-position: 50% 77px; height: 86.5%;">
    
    <div class="opacity" style="height: 100%;"></div>
    
      <div id='success' class="content" style="margin-top: 58px;">
      

        <div class="panel panel-default">
          <div class="panel-heading" style="padding: 5px 20px; background-color: #2c3e50; color: #FFF">
            <h3 style="opacity: 1">Success!</h3>
          </div>
          <div class="panel-body">
            <p style="color: #000; font-size: 16px; opacity: 1">
              <b>Congratulations!,</b>
            </p>
            <p style="color: #000; font-size: 16px; opacity: 1">
              You are now subscribed to <em style="color: #002386; font-weight: bold;">DocPro Accounting and Bookkeeping System.</em>
              Please check your email for the activation mail that we have sent to setup your account. Thank you!
            </p>
            <a href="<?php echo base_url();?>">Go to Home</a>
          </div>
        </div>

      
      </div>

    </section>