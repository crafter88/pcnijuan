<?php include 'fragments/head.php';?>
</head>
	<body>
		<h1>PAGE NOT FOUND</h1>
	</body>
</html>